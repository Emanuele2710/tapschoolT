
package loginprof;
import java.io.*;

/**
 *
 * @author Fabio
 */
public class LoginProf {

    String username="";
    String password="";
    String s=vett.split(";");
    
     public void login(String usernameProf,String password)
        {
            System.out.println("inserisci il tuo username");
            
            System.out.println("inserisci La tua password");
        }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
       
    }
    
}
